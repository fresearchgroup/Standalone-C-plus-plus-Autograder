 ./eval_assign.py -r ../single/reference.cpp -s ../single/sample-submissions-by-students/sub5.cpp -i ../single/input1,../single/input2,../single/input3 -k 123
